# Solv-In project instructions

- Product: Solv-In, an AI-assisted Property & Casualty insurance claims platform.
- Frontend: Angular + TypeScript in `/frontend`.
- Backend: Python + FastAPI in `/backend`.
- Database: MongoDB.
- Keep the sidebar to exactly five primary items: Dashboard, Claims, New FNOL, Reports, Settings.
- Put detailed functions inside relevant pages/tabs, not as extra sidebar items.
- Never replace Angular, FastAPI or MongoDB without explicit approval.
- Never introduce Firebase/Firestore unless requested.
- Use fictional demo data only in UI development.
- Do not invent missing claim facts, policy wording, prices, measurements or damage causes.
- Keep AI assessments preliminary, show sources/confidence/limitations, and require authorised human review.
- Never automatically approve, reject or settle claims or make final coverage, liability or fraud decisions.
- Use Python Decimal for financial calculations; never rely on an LLM for arithmetic.
- Keep secrets in environment variables. Never expose API keys in Angular or commit `.env`.
- Enforce tenant isolation and role permissions on the backend before production.
- Add tests for business logic and API endpoints.
