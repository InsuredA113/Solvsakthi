# Solv-In FastAPI backend

Install dependencies with `pip install -r requirements.txt`, copy `.env.example` to `.env`, then run:
`uvicorn app.main:app --reload`

Interactive API documentation: http://127.0.0.1:8000/docs

MongoDB must be running for `/api/claims` operations. The dashboard summary endpoint intentionally returns labelled fictional demo metrics.
