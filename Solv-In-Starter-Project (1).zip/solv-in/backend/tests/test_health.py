from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_endpoint_returns_application_name():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["application"] == "Solv-In"
