from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pymongo.errors import PyMongoError
from .config import CORS_ORIGINS
from .database import get_database, database_is_available
from .models import ClaimCreate

app = FastAPI(
    title="Solv-In API",
    description="Development API for the Solv-In P&C claims platform.",
    version="0.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {
        "status": "healthy",
        "application": "Solv-In",
        "database": "connected" if database_is_available() else "disconnected"
    }

@app.get("/api/dashboard/summary")
def dashboard_summary():
    return {
        "data_mode": "demo",
        "message": "Fictional sample figures for UI development only.",
        "total_claims": 1248,
        "new_claims": 342,
        "under_investigation": 278,
        "pending_approval": 167,
        "settled_claims": 260
    }

@app.get("/api/claims")
def list_claims():
    if not database_is_available():
        raise HTTPException(status_code=503, detail="MongoDB is unavailable. Start MongoDB and try again.")
    try:
        rows = list(get_database()["claims"].find({}, {"_id": 0}).sort("created_at", -1).limit(100))
        return {"items": rows, "count": len(rows)}
    except PyMongoError as exc:
        raise HTTPException(status_code=503, detail="Unable to read claims from MongoDB.") from exc

@app.post("/api/claims", status_code=201)
def create_claim(payload: ClaimCreate):
    if not database_is_available():
        raise HTTPException(status_code=503, detail="MongoDB is unavailable. No claim was saved.")
    db = get_database()
    try:
        sequence = db["counters"].find_one_and_update(
            {"_id": "claim_id"},
            {"$inc": {"sequence": 1}},
            upsert=True,
            return_document=True
        )
        claim_id = f"CLM-2026-{sequence['sequence']:06d}"
        record = payload.model_dump()
        record.update({"claim_id": claim_id, "status": "FNOL Received"})
        db["claims"].insert_one(record)
        record.pop("_id", None)
        return record
    except PyMongoError as exc:
        raise HTTPException(status_code=503, detail="Unable to save claim to MongoDB.") from exc
