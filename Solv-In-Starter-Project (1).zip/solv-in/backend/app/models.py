from datetime import datetime, timezone
from typing import Literal
from pydantic import BaseModel, Field

class ClaimCreate(BaseModel):
    customer_name: str = Field(min_length=2, max_length=120)
    policy_number: str = Field(min_length=2, max_length=80)
    claim_type: Literal["Property", "Casualty"]
    incident_date: str
    incident_description: str = Field(min_length=5, max_length=5000)
    currency: str = Field(default="INR", min_length=3, max_length=3)

class ClaimRecord(ClaimCreate):
    claim_id: str
    status: str = "FNOL Received"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
