# Solv-In scope and safeguards

Solv-In supports Property and Casualty insurance claim workflows.

Planned modules:
1. Foundation and architecture
2. Dashboard and navigation
3. Authentication, RBAC and tenant isolation
4. Claims management and FNOL
5. Document management
6. AI document extraction
7. AI-assisted claim field population
8. AI image damage assessment
9. Damage estimation
10. Deterministic actuarial calculation engine
11. Estimate comparison
12. Preliminary assessment reports
13. Gmail intake
14. Workflow and adjuster assignment
15. Customer portal
16. Insurer portal
17. AI provider management
18. Audit history and bulk operations
19. Testing and deployment readiness

Safeguards:
- AI assessments are preliminary and must be reviewed by authorised humans.
- Never automatically approve, reject or settle a claim.
- Never make final coverage, liability or fraud decisions.
- Never invent missing claim data, policy wording, prices or measurements.
- Use verified sources and retain provenance for extracted data.
- Calculate financial values deterministically in Python using Decimal and actual policy terms.
- Enforce tenant isolation and role permissions on the backend before production.
