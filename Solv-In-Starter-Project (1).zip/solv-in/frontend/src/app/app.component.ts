import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { environment } from '../environments/environment';

interface Claim {
  claim_id: string;
  customer_name: string;
  claim_type: string;
  status: string;
  updated: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  private http = inject(HttpClient);
  activePage = 'Dashboard';
  apiStatus = 'Checking API…';
  claims: Claim[] = [
    { claim_id: 'CLM-2026-000001', customer_name: 'Sarah Johnson', claim_type: 'Property', status: 'New', updated: '2 hours ago' },
    { claim_id: 'CLM-2026-000002', customer_name: 'Michael Chen', claim_type: 'Casualty', status: 'Investigation', updated: '3 hours ago' },
    { claim_id: 'CLM-2026-000003', customer_name: 'Emma Davis', claim_type: 'Property', status: 'Assessment', updated: '4 hours ago' },
    { claim_id: 'CLM-2026-000004', customer_name: 'Robert Wilson', claim_type: 'Casualty', status: 'Pending approval', updated: '5 hours ago' }
  ];

  navigation = ['Dashboard', 'Claims', 'New FNOL', 'Reports', 'Settings'];

  ngOnInit(): void {
    this.http.get<{status: string}>(`${environment.apiBaseUrl}/health`).subscribe({
      next: (result) => this.apiStatus = `API ${result.status}`,
      error: () => this.apiStatus = 'API unavailable – start the FastAPI server'
    });
  }

  selectPage(page: string): void {
    this.activePage = page;
  }
}
